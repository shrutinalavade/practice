/*const AWS = require('aws-sdk');
const AWSMock = require('aws-sdk-mock');
const { stringify } = require('uuid');
const expect = require('chai').expect;
const testdata=require('./testcase');
const list=require('../post/get')
const assert = require('assert')
const getlist=require('../post/list')
const deletepost=require('../post/delete');
const putpost=require('../post/create')
const updatepost=require('../post/update')
//const responseCode=require('../functions/index')
describe('the module', () => {
    it('should mock getItem from DynamoDB', async () => {
      AWSMock.setSDKInstance(AWS);   
     try{
      // Mocking DynamoDB.getItem()
      AWSMock.mock('DynamoDB.DocumentClient', 'query', (params, callback) => {
        console.log('DynamoDB', 'getItem', 'mock called')
        callback(null,testdata.response);
      })
           let event={
            pathParameters:{
              id:'5c5b87d0-a06b-11ec-bc23-87c061c2d2d6'  
            }        
           }
          process.env.DYNAMO_TABLE_NAME='studentTable'
           const result= await list.getPost(event);
           console.log(result);
           console.log(testdata.response)
          //expect(result).to.be.equals(testdata.response) 
        expect (result.statusCode).to.equal(200);
          //result.expect(result.statuscode).to.eql(200)
         //assert.equal(result,testdata.response);
         expect(result).to.eql(200);
         AWSMock.restore('DynamoDB'); 
     }catch(err){
       throw err;
     }
    })
      it('should mock listItem to DynamoDB', async () => {
        AWSMock.setSDKInstance(AWS);
        // Mocking DynamoDB.getItem()
        AWSMock.mock('DynamoDB', 'scan', (params, callback) => {
          console.log('DynamoDB', 'scan', 'mock called')
          callback(null,testdata.response);
        });
        const result = await getlist.listPosts(null);
       // expect(result.statuscode).to.be.equals(200)
        //expect(result.body).to.equal(testdata.response);
        expect (result.statusCode).to.equal(200)
        console.log(result);
        AWSMock.restore('DynamoDB'); 
      });
      it('should mock putpost from DynamoDB', async () => {
        AWSMock.setSDKInstance(AWS);    
        // Mocking DynamoDB.getItem()
        AWSMock.mock('DynamoDB', 'put', (params, callback) => {
          console.log('DynamoDB', 'deleteItem', 'mock called')
          callback(null);
        });
        var event={    
          body:{    
            
              "postTitle":"four",
              "postBody":"4body",
                 "imgUrl":"4url",
                 "tags":"4tag"
          
          } 
        }
        const result = await putpost.createPost(event);
       // expect(result).to.eql({ message: 'Post deleted successfully' });
        expect (result.statusCode).to.equal(200);
        AWSMock.restore('DynamoDB'); 
      });
      it('should mock putpost from DynamoDB', async () => {
        AWSMock.setSDKInstance(AWS);      
        // Mocking DynamoDB.getItem()
        AWSMock.mock('DynamoDB', 'update', (params, callback) => {
          console.log('DynamoDB', 'update', 'mock called')
          callback(null);
        });
        var event={    
          body:{    
            "id":"d6dfb6f0-a031-11ec-9345-8b7cb362b4b6",
            "postTitle":"firstnew",
            "postBody":"1bodynew",
            "imgUrl":"1urlnew",
             "tags":"1tagnew"
          } 
        }
        const result = await updatepost.updatePost(event);
       // expect(result).to.eql({ message: 'Post deleted successfully' });
        expect (result.statusCode).to.equal(200);
        AWSMock.restore('DynamoDB'); 
      });
      it('should mock deletepost from DynamoDB', async () => {
        AWSMock.setSDKInstance(AWS);      
        // Mocking DynamoDB.getItem()
        AWSMock.mock('DynamoDB', 'delete', (params, callback) => {
          console.log('DynamoDB', 'delete', 'mock called')
          callback(null);
        });
        var event={    
          body:{    
            "id":"d6dfb6f0-a031-11ec-9345-8b7cb362b4b6"
          } 
        }
        const result = await deletepost.deletePost(event);
        console.log(result)
       // expect(result).to.eql({ message: 'Post deleted successfully' });
        expect (result.statusCode).to.equal(200);
        AWSMock.restore('DynamoDB'); 
      });
  });*/

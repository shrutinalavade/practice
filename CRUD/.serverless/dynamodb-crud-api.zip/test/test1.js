/*const chai = require('chai');
const chaiHttp = require('chai-http');
const AWSMock = require('aws-sdk-mock');
const getlist=require('../service/list')
const deletepost=require('../service/delete');
const putpost=require('../service/create')
const updatepost=require('../service/update')
chai.use(chaiHttp);
const expect = chai.expect;


 describe("Mocking AWS Services", () => {
     var data={
      body: {
        "id":"d6dfb6f0-a031-11ec-9345-8b7cb362b4b6",
        "postTitle":"firstnew",
        "postBody":"1bodynew",
        "imgUrl":"1urlnew",
         "tags":"1tagnew"
     }
       
      }
   
   it('Testing whether data already exsist',()=>{
       AWSMock.mock('DynamoDB.DocumentClient','scan',(params,callback)=>{
             callback(null,"successful");
         })
         getlist.listPosts(data,null,(err,res)=>{
           //console.log("hello");
             if(err){
                 console.log('error')
             }
           expect(res.body).to.equal(data) 
           console.log("data",data);
         })
       })
     })

     describe("Mocking AWS Services", () => {
          var data={
           body:{
              
             "postTitle": "new post",
              "tags": "newtag"
          }
          }
        it('checking post request ',()=>{
            AWSMock.mock('DynamoDB.DocumentClient','post',(params,callback)=>{
                  callback(null);
              })
              updatepost.updatePost(data,null,(err,res)=>{
                  if(err){
                      console.log('error')
                  }
               expect(res.statusCode).to.equal(200) 
               })
          })
 })

 describe("Mocking AWS Services", () => {

     it('Checking delete request ',()=>{
         AWSMock.mock('DynamoDB.DocumentClient','delete',(params,callback)=>{
               callback(null);
           })
           deletepost.deletePost({pathParameters:{id:"d6dfb6f0-a031-11ec-9345-8b7cb362b4b6"}},null,(err,res)=>{
             //console.log("hello");
               if(err){
                   console.log('error')
               }
               
             
             expect(res.statusCode).to.equal(200) ;
     
           })
         
       })
     })
     */
          
    